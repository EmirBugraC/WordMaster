import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenu extends JFrame {
    private JPanel mainPanel;
    private JButton logInButton;
    private JButton guestButton;
    private JButton quitButton;
    private JLabel gameNameLabel;
    private JButton leaderboardButton;

    //Constructor for the form Main menu
    public MainMenu(String title) {
        //Sets the form title - super means use the Constructor in the parent class
        super(title);
        //closes the form when clicked close
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        //uses the panel set up
        this.setContentPane(mainPanel);

        //This part builds the form
        this.pack();

        logInButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //when clicked goes into LogIn form
                LogIn logIn = new LogIn("Log in");
                logIn.setLocationRelativeTo(null);
                logIn.setVisible(true);
            }

        });
        guestButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //When clicked sets the player as guest by using the guest constructor and goes into the game
                Game game = new Game(new Player("Guest"));
                game.setLocationRelativeTo(null);
                game.setVisible(true);
            }
        });

        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //ends the game before it even starts
                System.exit(0);
            }
        });
        leaderboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //when clicked opens the leaderboard
                Leaderboard lb = new Leaderboard("Leaderboard");
                lb.setLocationRelativeTo(null);
                lb.setVisible(true);
            }
        });
    }

    public static void displayForm() {
        //method to start the game used in main class
        JFrame frame = new MainMenu("Main Menu");
        //Makes the form appear in the middle of the screen
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

}