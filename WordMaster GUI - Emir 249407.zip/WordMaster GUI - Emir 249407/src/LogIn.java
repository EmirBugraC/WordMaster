import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LogIn extends JFrame {
    private JPanel logInPanel;
    private JButton enterButton;
    private JButton cancelButton;
    private JTextField userNameField;
    private JPasswordField passwordField;
    private JCheckBox viewPasswordBox;

    public LogIn(String title) {
        super(title);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setContentPane(logInPanel);
        this.pack();

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //closes the form
                closeForm();
            }
        });
        viewPasswordBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //when is checked shows the password.
                if (viewPasswordBox.isSelected()) {
                    passwordField.setEchoChar((char)0);
                } else {
                    passwordField.setEchoChar('*');
                }
            }
            });
        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //calls the checkUserName on the CheckData class to
                //check whether the entered username and password match.
                String name = userNameField.getText();
                String password = new String(passwordField.getPassword());
                CheckData checkData = new CheckData();
                checkData.checkUserName(name,password);
            }
        });
    }
    private void closeForm(){
        //a method to close the form.
        this.setVisible(false);
    }
}

