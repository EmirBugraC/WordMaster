import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Options extends JFrame {
    private JPanel optionsPanel;
    private JButton OKButton;
    private JSpinner guessSpinner;
    private JSpinner wordLengthSpinner;


    public Options (Player player) {
        super("Options");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setContentPane(optionsPanel);
        //sets the max and min values for both the amount of turns and the length of the word
        guessSpinner.setModel(new SpinnerNumberModel(1, 1, 15, 1));
        wordLengthSpinner.setModel(new SpinnerNumberModel(4, 4, 14, 1));
        this.pack();

        OKButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //when clicked object will be set to whatever values the user selected.
                player.setEstimatedTurns((Integer)guessSpinner.getValue());
                player.setGuessWordLength(((Integer)wordLengthSpinner.getValue()));
                Game game = new Game(player);
                game.setLocationRelativeTo(null);
                game.setVisible(true);
                dispose();
            }
        });
    }
}

