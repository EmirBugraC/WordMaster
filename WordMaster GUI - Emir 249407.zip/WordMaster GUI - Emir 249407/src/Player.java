public class Player {
    private String userName;
    private String password;
    private int gamesPlayed;
    private int highScore;
    private int turnsTaken;
    private int guessWordLength;
    private int estimatedTurns;
    public static int MIN_GUESSES = 1;
    public static int MIN_WORDLENGTH = 4;

    public Player() {
        //general constructor
        userName = "";
        password = "";
    }
    public Player(String userName) {
        //constructor specifically for the guest
        this.userName = userName;
        password ="";
        this.gamesPlayed = 0;
        this.highScore = 0;
        estimatedTurns = MIN_GUESSES;
        guessWordLength = MIN_WORDLENGTH;
    }

    public Player(String userName, String password, int gamesPlayed, int highScore) {
        //construct specifically for the player
        this.userName = userName;
        this.password = password;
        this.gamesPlayed = gamesPlayed;
        this.highScore = highScore;
        estimatedTurns = MIN_GUESSES;
        guessWordLength = MIN_WORDLENGTH;

    }

    public String getUserName() { //getter for username
        return userName;
    }

    public void setUserName(String userName) { //setter for username
        this.userName = userName;
    }

    public String getPassword() { //getter for password
        return password;
    }

    public void setPassword(String password) { //setter for password
        this.password = password;
    }

    public void incGamesPlayed() {
        //Increases the number of games played by 1
        gamesPlayed++;
    }

    public int getHighScore() { //Getter for highScore
        return highScore;
    }

    public boolean setHighScore(int highScore) {
        //Sets the current high score if it is greater than the previous high score
        if (this.highScore < highScore){
            this.highScore = highScore;
            return true;
        }
        return false;
    }

    public int getEstimatedTurns() { //getter for estimated turns
        return estimatedTurns;
    }

    public void setEstimatedTurns(int estimatedTurns) { //setter for estimated turns
        this.estimatedTurns = estimatedTurns;
    }

    public int getTurnsTaken() { //getter for player turns
        return turnsTaken;
    }

    public void setTurnsTaken(int turnsTaken) {
        // setter for player turns
        this.turnsTaken = 0;
    }

    public void incTurnsTaken(){
        //Increases the number of turns taken by 1
        turnsTaken++;
    }

    public int getGuessWordLength() { //getter for length of the player guess
        return guessWordLength;
    }

    public void setGuessWordLength(int guessWordLength) { //getter for length of the player guess
        this.guessWordLength = guessWordLength;
    }

    public String toString(){
        //toString writes all the fields of the class as csv e.g. Emir,password,12,1400
        return this.userName+","+
                this.password+","+
                this.gamesPlayed+","+
                this.highScore;
    }
}