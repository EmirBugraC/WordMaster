import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Leaderboard extends JFrame {
    private JPanel leaderboardPanel;
    private JTextArea leaderboardTextArea1;
    private JButton closeButton;
    private JTextArea leaderboardTextArea2;
    private JTextArea leaderboardTextArea3;
    private JTextArea leaderboardTextArea4;
    private JTextArea leaderboardTextArea5;

    public Leaderboard (String title) {
        super(title);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setContentPane(leaderboardPanel);
        this.pack();
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                closeForm();
            }
        });
    }
    private void closeForm() {
        //method to close the form
        this.setVisible(false);
    }
}

