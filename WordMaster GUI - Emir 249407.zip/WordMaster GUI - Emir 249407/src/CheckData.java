import javax.swing.*;

public class CheckData {
    Player player = new Player();
    static Players players = new Players();
    //made it static and created a getter because otherwise
    //every time I created a new player it was replacing other existing players in players.txt
    //I could fix in other ways, but I would have to change most of my code, so I used it this way
    public static Players getPlayers() {
        return players;
    }

    public void checkUserName(String name, String password){
        players.readPlayerFile();
        if (!name.equals("")){ //checks if typed username is empty. if it is displays error message line 54
            if (players.findPlayer(name)==null){
                //Checks if the player exists If the player does not exist checks if the password is allowable
                //if the password allowable asks if they want to create a new account.
                if (checkNewPassword(password)){
                    int choice = JOptionPane.showConfirmDialog(null,
                            "Do you want to create a new account?",
                            "Register",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.QUESTION_MESSAGE);

                    if (choice == JOptionPane.YES_OPTION){
                        //if the answer is yes creates a new account and goes into game.
                        //Also writes the player data to the players.txt file.
                        Player player = new Player (name, password, 0, 0);
                        players.addPlayer(player);
                        players.writePlayerFile();
                        Game game = new Game(player);
                        game.setLocationRelativeTo(null);
                        game.setVisible(true);
                    }
                } else { //if the password is not allowable error message
                    JOptionPane.showMessageDialog(null,
                            "Please enter a valid password!",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }else { // if username already exists checks the password and if its correct goes into the game
                if (checkPassword(name, password)){
                    player=players.findPlayer(name);
                    Game game = new Game(player);
                    game.setLocationRelativeTo(null);
                    game.setVisible(true);
                } else{ //if the password is wrong error message
                    JOptionPane.showMessageDialog(null,
                            "Wrong password!",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
                JOptionPane.showMessageDialog(null,
                        "Username cannot be empty!\n" +
                                "Please enter a valid username!",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
        }
    }



    public static boolean checkNewPassword(String password){
        int hasUpperCase = 0;
        int hasLowerCase = 0;
        int hasInteger = 0;
        int hasSpecial = 0;
        for (int i = 0; i < password.length(); i++){
            //for loop goes between each letter in the password
            //and checks if it has the requirements to be used as a password
            char c = password.charAt(i);
            if (Character.isUpperCase(c)){
                hasUpperCase++;
            } else if (Character.isLowerCase(c)){
                hasLowerCase++;
            }else if (Character.isDigit(c)){
                hasInteger++;
            }else {
                hasSpecial++;
            }
        }
        if (hasUpperCase > 0 && hasLowerCase > 0 && hasInteger > 0 && hasSpecial > 0){
            return true;
        }else {
            return false;
        }
    }

    public boolean checkPassword(String name, String password){
        //for already existed players checks if the password matches with the password in the database
        players.readPlayerFile();
        player = players.findPlayer(name);
        if (password.equals(player.getPassword())){
            return true;
        }else {
            return false;
        }
    }
}
