import java.util.ArrayList;

public class Players {
    private final String WORDFILE = "resources/players.txt";
    private ArrayList<Player> players;

    public Players() {
        //Constructor for the Players class. Initialises the players ArrayList.
        players = new ArrayList<>();
    }

    public void addPlayer(Player player){
        //Adds a new player to the ArrayList
        players.add(player);
    }

    public void readPlayerFile() {
        //Reads the file players.txt and updates the players ArrayList
        ArrayList<String> data = FileIO.readDataFromFile(WORDFILE);
        players = new ArrayList<>();
        //Use the ArrayList<String> to generate new register entries
        for (String str: data) {
            String[] playerData = str.split(",");
            String name = playerData[0];
            String password = playerData[1];
            int num1 = Integer.parseInt(playerData[2]);
            int num2 = Integer.parseInt(playerData[3]);
            Player player = new Player(name,password,num1,num2);
            players.add(player);
        }
    }

    public void writePlayerFile(){
        //Writes the ArrayList to the players.txt file
        ArrayList<String> data = new ArrayList<>();
        //Generate a ArrayList<String> to write the data to the register
        for (Player player: players) {
            data.add(player.toString());
        }
        FileIO.writeDataToFile(WORDFILE, data);
    }

    public Player findPlayer(String name) {
        //Searches through the register ArrayList to find a matching player and returns it
        for (Player player : players) {
            if (name.equals(player.getUserName())) {
                return player;
            }
        }
        return null;
    }

    public void updatePlayerList(Player searchPlayer){
        //Searches through the register ArrayList to find a matching player
        //based on the userName. If the names match then update the specific player
        //or add the player data to the list.
        boolean playerFound = false;
        for (int i = 0; i< players.size(); i++){
            Player player = players.get(i);
            if (player.getUserName().equals(searchPlayer.getUserName())){
                player.setHighScore(searchPlayer.getHighScore());
                player.incGamesPlayed();
                players.set(i,player);
                playerFound = true;
            }
        }
        if(!playerFound){
            players.add(searchPlayer);
        }
    }
}
