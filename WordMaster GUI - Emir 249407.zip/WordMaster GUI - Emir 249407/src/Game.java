import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Game extends JFrame {
    private JPanel gamePanel;
    private JTextField guessField;
    private JButton newGameButton;
    private JButton optionsButton;
    private JButton backButton;
    private JButton enterButton;
    private JLabel estTurnsLabel;
    private JLabel turnsLabel;
    private JLabel highScoreLabel;
    private JLabel userNameLabel;
    private JCheckBox cheatModeCheckBox;
    private JButton leaderboardButton;
    private JLabel wordArrayLabel;
    private JLabel secretWordLabel;
    private WordList wordList;

    public Game(Player player) {
        super("Game Form");
        gamePanel.setPreferredSize(new Dimension(470,250));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setContentPane(gamePanel);
        this.pack();
        wordList = new WordList(); //initializes the WordList class
        wordList.setSecretWord(player.getGuessWordLength()); //sets the random secret word
        setLabels(player); //sets the labels

        newGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //when clicked resets everything to the original state
                enterButton.setEnabled(true);
                guessField.setText("");
                player.setGuessWordLength(player.MIN_WORDLENGTH);
                player.setEstimatedTurns(player.MIN_GUESSES);
                player.setTurnsTaken(0);
                wordList.setSecretWord(player.getGuessWordLength());
                if (cheatModeCheckBox.isSelected()){
                    cheatModeCheckBox.setSelected(false);
                    secretWordLabel.setVisible(false);
                }
                setLabels(player);
                secretWordLabel.setText(wordList.getSecretWord());
                JOptionPane.showMessageDialog(null,
                        "Starting a new game.");
            }
        });

        optionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //when clicked shows the Options form
                Options options = new Options(player);
                options.setLocationRelativeTo(null);
                options.setVisible(true);
                dispose();
            }
        });
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //closes the form
                closeForm();
            }
        });
        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String guess = guessField.getText();
                //gets an input from the player for their guess
                Players players = CheckData.getPlayers();
                    if (player.getTurnsTaken() == player.getEstimatedTurns()){
                        //game continues until the turns taken equals to amount of turns chosen by the player
                        //and if lost displays a message saying player lost and disables the enter button.
                        enterButton.setEnabled(false);
                        JOptionPane.showMessageDialog(null,
                                "You Lost!\n" +
                                        "Try again later.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                        if (!player.getUserName().equals("Guest")){
                            //if the player played the game as guest does not write it to database.
                            players.updatePlayerList(player);
                            players.writePlayerFile();
                        }
                    } else{
                        if (guess.length() == wordList.getSecretWord().length()){
                            //checks whether the length of the words match. if not displays an error message line 125
                            player.incTurnsTaken();
                            wordList.compareWords(guess);
                            setLabels(player); //resets game labels each time turn number changes
                            if (wordList.getSecretWord().equals(guess)){
                                //if the guessed word matches the secret word player wins and displays a message
                                //saying you won! Also disables the enter button
                                enterButton.setEnabled(false);
                                int score = getScore(player.getEstimatedTurns(),
                                        player.getTurnsTaken(),
                                        wordList.getSecretWord().length());
                                //calculates the score with using the method called getScore
                                // and displays the player's score with the win message.
                                JOptionPane.showMessageDialog(null,
                                        "You Have Won!!\n" +
                                                "Your Score is: "+ score);
                                setLabels(player); //resets game labels according to player's stats
                                if (!player.getUserName().equals("Guest")){
                                    //if the player played the game as guest does not write it to database.
                                    players.updatePlayerList(player);
                                    players.writePlayerFile();
                                }
                                if (player.getHighScore()<score){
                                    //checks if the players current score is higher than their highest score yet.
                                    //if yes sets players new highest score. does the same thing
                                    // if the player played as a guest but does not save it to database
                                    player.setHighScore(score);
                                    setLabels(player);
                                    JOptionPane.showMessageDialog(null,
                                                "New High Score! "+ score);
                                        if (!player.getUserName().equals("Guest")){
                                            //if the player played the game as guest does not write it to database.
                                            players.updatePlayerList(player);
                                            players.writePlayerFile();
                                        }
                                }
                            }else guessField.setText("");
                            //if player did not guess the word empties the text area each turn.
                        }else {
                            JOptionPane.showMessageDialog(null,
                                    "Word lengths does not match!\n" +
                                            "Try typing another word",
                                    "Error",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                    }
            }
        });
        leaderboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //when clicked opens the leaderboard
                Leaderboard lb = new Leaderboard("Leaderboard");
                lb.setLocationRelativeTo(null);
                lb.setVisible(true);
            }
        });
        cheatModeCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //when checked shows reveals the secret Word
                if (cheatModeCheckBox.isSelected()){
                    secretWordLabel.setVisible(true);
                } else {
                secretWordLabel.setVisible(false);
                }
            }
        });
    }
    private void closeForm() {
        //method to close the form
        this.setVisible(false);
    }
    private String getPlayerName(Player player) {
        //a method to show player's name
        return "Player name: " + player.getUserName();
    }
    private String getHighScore(Player player) {
        //a method to show player's highest score
        return "High Score:  " + player.getHighScore();
    }
    private String getPlayerTurn(Player player) {
        //a method to show turns taken by the player
        return "Turns Taken: " + player.getTurnsTaken();
    }
    private String getEstimatedTurn(Player player) {
        //a method to show max reachable turn number for the player
        return "Estimated Turn: " + player.getEstimatedTurns();
    }
    private String getSecretWord(WordList wordList){
        //a method to show secretWord
        return wordList.getSecretWord();
    }
    private String getWordArray(){
        //a method to show wordArray
        return "" + wordList.getDisplayWordArray();
    }
    private void setLabels(Player player){
        //sets all the labels
        userNameLabel.setText(getPlayerName(player));
        turnsLabel.setText(getPlayerTurn(player));
        estTurnsLabel.setText(getEstimatedTurn(player));
        highScoreLabel.setText(getHighScore(player));
        wordArrayLabel.setText(getWordArray());
        secretWordLabel.setText(getSecretWord(wordList));
    }
    public int getScore(int estimatedTurns, int actualTurns, int wordLength){
        //Returns the player score according to this formula.
        return (100 / estimatedTurns * (estimatedTurns - actualTurns + 1)) * wordLength;
    }
}